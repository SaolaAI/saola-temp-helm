{{/*
Expand the name of the chart.
*/}}
{{- define "saola.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "saola.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart name and version as used by the chart label.
*/}}
{{- define "saola.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "saola.labels" -}}
helm.sh/chart: {{ include "saola.chart" . }}
{{ include "saola.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
environment: {{ .Values.global.environment }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "saola.selectorLabels" -}}
app.kubernetes.io/name: {{ include "saola.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "saola.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "saola.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
MongoDB URI with database
*/}}
{{- define "saola.mongoUri" -}}
{{- if .dbName }}
{{- printf "%s/%s?retryWrites=true&w=majority" .Values.config.mongodb.uri .dbName }}
{{- else }}
{{- printf "%s?retryWrites=true&w=majority" .Values.config.mongodb.uri }}
{{- end }}
{{- end }}

{{/*
Image repository and tag
*/}}
{{- define "saola.image" -}}
{{- $registry := .Values.global.imageRegistry -}}
{{- $repository := .image.repository | default .serviceName -}}
{{- $tag := .image.tag | default "latest" -}}
{{- printf "%s/%s:%s" $registry $repository $tag }}
{{- end }}

{{/*
Node selector for service
*/}}
{{- define "saola.nodeSelector" -}}
{{- if .nodeSelector }}
saola-group: {{ .nodeSelector }}
{{- else }}
saola-group: {{ .Values.global.nodeSelector.general }}
{{- end }}
{{- end }}

{{/*
Environment variables for AWS resources
*/}}
{{- define "saola.awsEnvVars" -}}
- name: AWS_REGION
  value: {{ .Values.config.aws.region }}
- name: S3_REGION
  value: {{ .Values.config.aws.region }}
- name: SQS_REGION
  value: {{ .Values.config.aws.region }}
{{- end }}

{{/*
Environment variables for service discovery
*/}}
{{- define "saola.serviceDiscoveryEnvVars" -}}
- name: SESSIONS_URI
  value: "http://sessions"
- name: ACCOUNTS_URI
  value: "http://accounts"
- name: TESTS_URI
  value: "http://tests"
- name: TESTS_RUNNER_URI
  value: "http://tests-runner"
- name: NOTIFICATIONS_URI
  value: "http://notifications"
- name: FLOWS_URI
  value: "http://flows"
- name: ELEMENTS_URI
  value: "http://elements"
- name: SCHEDULER_URI
  value: "http://scheduler"
- name: GATEWAY_URI
  value: "http://gateway"
- name: BROWSER_AGENT_URI
  value: "http://browser-agent"
- name: AI_BRIDGE_URI
  value: "http://ai-bridge"
- name: SCREENSHOTS_URI
  value: "http://screenshots"
- name: OPERATIONS_URI
  value: "http://operations"
{{- end }}

{{/*
Standard health check probes
*/}}
{{- define "saola.livenessProbe" -}}
livenessProbe:
  httpGet:
    path: {{ .path | default "/health/live" }}
    port: {{ .port }}
  initialDelaySeconds: {{ .Values.healthChecks.livenessProbe.initialDelaySeconds }}
  periodSeconds: {{ .Values.healthChecks.livenessProbe.periodSeconds }}
  timeoutSeconds: {{ .Values.healthChecks.livenessProbe.timeoutSeconds }}
  failureThreshold: {{ .Values.healthChecks.livenessProbe.failureThreshold }}
{{- end }}

{{- define "saola.readinessProbe" -}}
readinessProbe:
  httpGet:
    path: {{ .path | default "/health/ready" }}
    port: {{ .port }}
  initialDelaySeconds: {{ .Values.healthChecks.readinessProbe.initialDelaySeconds }}
  periodSeconds: {{ .Values.healthChecks.readinessProbe.periodSeconds }}
  timeoutSeconds: {{ .Values.healthChecks.readinessProbe.timeoutSeconds }}
  failureThreshold: {{ .Values.healthChecks.readinessProbe.failureThreshold }}
{{- end }}

{{/*
DataDog environment variables
*/}}
{{- define "saola.datadogEnvVars" -}}
- name: DD_SERVICE
  value: {{ .serviceName }}
- name: DD_ENV
  value: {{ .Values.config.datadog.environment }}
- name: DOGSTATSD_HOST
  value: {{ .Values.config.datadog.host }}
{{- end }}
